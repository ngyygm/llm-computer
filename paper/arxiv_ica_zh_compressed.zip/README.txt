Model-Native Computing Architecture (Chinese source for arXiv) — COMPRESSED

The CN paper uses vector TikZ figures (no large raster set), so it is
naturally compact; the two raster figures (analogy map, agent timeline)
are downscaled. Originals are NOT included here.

Main file: paper.tex
Compile:   pdflatex paper.tex  (paper.bbl included; no bibtex needed)
